import { createRequire } from 'module'; const require = createRequire(import.meta.url);

// src/lambda/custom-list-orgs.ts
import { DynamoDBClient } from "@aws-sdk/client-dynamodb";
import {
  DynamoDBDocumentClient,
  QueryCommand,
  BatchGetCommand
} from "@aws-sdk/lib-dynamodb";
var USERS_TABLE_NAME = process.env.USERS_TABLE_NAME || "BillingUsers";
var ORGANIZATIONS_TABLE_NAME = process.env.ORGANIZATIONS_TABLE_NAME || "BillingOrganizations";
var ddb = DynamoDBDocumentClient.from(new DynamoDBClient({}));
var CORS_HEADERS = {
  "Content-Type": "application/json",
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization"
};
function apiResponse(statusCode, body) {
  return { statusCode, headers: CORS_HEADERS, body: JSON.stringify(body) };
}
function resolveUserId(event) {
  const userId = event.requestContext?.authorizer?.userId;
  if (!userId) throw new Error("userId is required \u2014 must be authenticated");
  return userId;
}
async function getUserOrgMemberships(userId) {
  const result = await ddb.send(
    new QueryCommand({
      TableName: USERS_TABLE_NAME,
      IndexName: "userId-index",
      KeyConditionExpression: "#uid = :uid",
      ExpressionAttributeNames: { "#uid": "userId" },
      ExpressionAttributeValues: { ":uid": userId },
      ProjectionExpression: "orgId, accessRoles, groups, email, userFirstName, userLastName"
    })
  );
  return result.Items ?? [];
}
async function batchGetOrganizations(orgIds) {
  if (orgIds.length === 0) return [];
  const chunks = [];
  for (let i = 0; i < orgIds.length; i += 100) {
    chunks.push(orgIds.slice(i, i + 100));
  }
  const allOrgs = [];
  for (const chunk of chunks) {
    const result = await ddb.send(
      new BatchGetCommand({
        RequestItems: {
          [ORGANIZATIONS_TABLE_NAME]: {
            Keys: chunk.map((orgId) => ({ orgId })),
            ProjectionExpression: "orgId, #n, description, createdAt, updatedAt",
            ExpressionAttributeNames: { "#n": "name" }
          }
        }
      })
    );
    const items = result.Responses?.[ORGANIZATIONS_TABLE_NAME] ?? [];
    allOrgs.push(...items);
  }
  return allOrgs;
}
var handler = async (event) => {
  console.log("EVENT:", JSON.stringify(event));
  try {
    if (event.httpMethod === "OPTIONS") return apiResponse(200, {});
    if (event.httpMethod !== "GET") {
      return apiResponse(405, { error: "Method not allowed" });
    }
    const userId = resolveUserId(event);
    const memberships = await getUserOrgMemberships(userId);
    if (memberships.length === 0) {
      return apiResponse(200, { userId, organizations: [] });
    }
    const orgIds = memberships.map((m) => m.orgId).filter(Boolean);
    const orgs = await batchGetOrganizations(orgIds);
    const orgMap = new Map(orgs.map((org) => [org.orgId, org]));
    const organizations = memberships.map((membership) => {
      const org = orgMap.get(membership.orgId);
      if (!org) return null;
      return {
        orgId: org.orgId,
        name: org.name,
        description: org.description,
        accessRoles: membership.accessRoles ?? [],
        groups: membership.groups ?? [],
        createdAt: org.createdAt
      };
    }).filter(Boolean);
    return apiResponse(200, { userId, organizations });
  } catch (error) {
    console.error("[LIST_ORGS] Handler error:", error);
    return apiResponse(500, { error: "Failed to list organizations" });
  }
};
export {
  handler
};
//# sourceMappingURL=custom-list-orgs.js.map
