import { createRequire } from 'module'; const require = createRequire(import.meta.url);

// src/lambda/accept-invitation.ts
import { DynamoDBClient } from "@aws-sdk/client-dynamodb";
import {
  DynamoDBDocumentClient,
  GetCommand,
  PutCommand,
  UpdateCommand
} from "@aws-sdk/lib-dynamodb";
import {
  CognitoIdentityProviderClient,
  AdminCreateUserCommand,
  AdminSetUserPasswordCommand,
  AdminGetUserCommand
} from "@aws-sdk/client-cognito-identity-provider";
import { randomUUID } from "crypto";
var COGNITO_USER_POOL_ID = process.env.COGNITO_USER_POOL_ID || "";
var USERS_TABLE_NAME = process.env.USERS_TABLE_NAME || "BillingUsers";
var INVITATIONS_TABLE_NAME = process.env.INVITATIONS_TABLE_NAME || "BillingInvitations";
var ddb = DynamoDBDocumentClient.from(new DynamoDBClient({}));
var cognito = new CognitoIdentityProviderClient({});
var CORS_HEADERS = {
  "Content-Type": "application/json",
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization"
};
function apiResponse(statusCode, body) {
  return { statusCode, headers: CORS_HEADERS, body: JSON.stringify(body) };
}
async function validateInvitation(invitationCode) {
  const result = await ddb.send(
    new GetCommand({
      TableName: INVITATIONS_TABLE_NAME,
      Key: { invitationId: invitationCode }
    })
  );
  const invitation = result.Item;
  if (!invitation) {
    return { valid: false, error: "Invitation not found", statusCode: 404 };
  }
  if (invitation.status !== "PENDING" /* PENDING */) {
    return {
      valid: false,
      error: `Invitation is ${invitation.status.toLowerCase()}`,
      statusCode: 409
    };
  }
  if (invitation.expiresAt) {
    const expiryDate = new Date(invitation.expiresAt);
    if (expiryDate < /* @__PURE__ */ new Date()) {
      await ddb.send(
        new UpdateCommand({
          TableName: INVITATIONS_TABLE_NAME,
          Key: { invitationId: invitationCode },
          UpdateExpression: "SET #status = :expired, updatedAt = :now",
          ExpressionAttributeNames: { "#status": "status" },
          ExpressionAttributeValues: {
            ":expired": "EXPIRED" /* EXPIRED */,
            ":now": (/* @__PURE__ */ new Date()).toISOString()
          }
        })
      );
      return { valid: false, error: "Invitation has expired", statusCode: 409 };
    }
  }
  return { valid: true, invitation };
}
async function createCognitoUser(email, password) {
  try {
    const existing = await cognito.send(
      new AdminGetUserCommand({
        UserPoolId: COGNITO_USER_POOL_ID,
        Username: email
      })
    );
    const sub2 = existing.UserAttributes?.find((a) => a.Name === "sub")?.Value;
    if (sub2) return sub2;
  } catch (err) {
    if (err.name !== "UserNotFoundException") throw err;
  }
  const createResult = await cognito.send(
    new AdminCreateUserCommand({
      UserPoolId: COGNITO_USER_POOL_ID,
      Username: email,
      UserAttributes: [
        { Name: "email", Value: email },
        { Name: "email_verified", Value: "true" }
      ],
      TemporaryPassword: `Temp${randomUUID().slice(0, 8)}!`,
      MessageAction: "SUPPRESS"
    })
  );
  await cognito.send(
    new AdminSetUserPasswordCommand({
      UserPoolId: COGNITO_USER_POOL_ID,
      Username: email,
      Password: password,
      Permanent: true
    })
  );
  const sub = createResult.User?.Attributes?.find((a) => a.Name === "sub")?.Value;
  return sub || email;
}
var handler = async (event) => {
  console.log("EVENT:", JSON.stringify({ ...event, body: "[REDACTED]" }));
  try {
    if (event.httpMethod === "OPTIONS") return apiResponse(200, {});
    if (event.httpMethod !== "POST") {
      return apiResponse(405, { error: "Method not allowed" });
    }
    let body;
    try {
      body = JSON.parse(event.body || "{}");
    } catch {
      return apiResponse(400, { error: "Invalid JSON in request body" });
    }
    const { invitationCode, email, password, firstName, lastName } = body;
    if (!invitationCode) return apiResponse(400, { error: "invitationCode is required" });
    if (!email) return apiResponse(400, { error: "email is required" });
    if (!password) return apiResponse(400, { error: "password is required" });
    if (!firstName) return apiResponse(400, { error: "firstName is required" });
    if (!lastName) return apiResponse(400, { error: "lastName is required" });
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email)) {
      return apiResponse(400, { error: "Invalid email format" });
    }
    if (password.length < 8) {
      return apiResponse(400, { error: "Password must be at least 8 characters" });
    }
    const validationResult = await validateInvitation(invitationCode);
    if (!validationResult.valid) {
      return apiResponse(validationResult.statusCode, { error: validationResult.error });
    }
    const invitation = validationResult.invitation;
    const { orgId, accessRoles = [], groups = [] } = invitation;
    let userId;
    try {
      userId = await createCognitoUser(email, password);
    } catch (err) {
      console.error("[ACCEPT_INVITATION] Cognito error:", err);
      if (err.name === "UsernameExistsException") {
        return apiResponse(409, { error: "A user with this email already exists" });
      }
      return apiResponse(500, { error: "Failed to create user account" });
    }
    const now = (/* @__PURE__ */ new Date()).toISOString();
    try {
      await ddb.send(
        new PutCommand({
          TableName: USERS_TABLE_NAME,
          Item: {
            userId,
            orgId,
            userFirstName: firstName.trim(),
            userLastName: lastName.trim(),
            email: email.trim().toLowerCase(),
            accessRoles,
            groups,
            invitationId: invitationCode,
            createdAt: now,
            updatedAt: now
          },
          ConditionExpression: "attribute_not_exists(userId) AND attribute_not_exists(orgId)"
        })
      );
    } catch (err) {
      if (err.name === "ConditionalCheckFailedException") {
        return apiResponse(409, { error: "User already exists in this organization" });
      }
      throw err;
    }
    await ddb.send(
      new UpdateCommand({
        TableName: INVITATIONS_TABLE_NAME,
        Key: { invitationId: invitationCode },
        UpdateExpression: "SET #status = :accepted, acceptedBy = :userId, acceptedAt = :now, updatedAt = :now",
        ExpressionAttributeNames: { "#status": "status" },
        ExpressionAttributeValues: {
          ":accepted": "ACCEPTED" /* ACCEPTED */,
          ":userId": userId,
          ":now": now
        }
      })
    );
    console.log(`[ACCEPT_INVITATION] invitationId=${invitationCode} userId=${userId} orgId=${orgId}`);
    return apiResponse(200, {
      message: "Invitation accepted successfully",
      userId,
      orgId,
      email: email.trim().toLowerCase()
    });
  } catch (error) {
    console.error("[ACCEPT_INVITATION] Handler error:", error);
    return apiResponse(500, { error: "Internal server error" });
  }
};
export {
  handler
};
//# sourceMappingURL=accept-invitation.js.map
