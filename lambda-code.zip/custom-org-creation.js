import { createRequire } from 'module'; const require = createRequire(import.meta.url);

// src/lambda/custom-org-creation.ts
import { DynamoDBClient } from "@aws-sdk/client-dynamodb";
import {
  DynamoDBDocumentClient,
  TransactWriteCommand
} from "@aws-sdk/lib-dynamodb";
import {
  CognitoIdentityProviderClient,
  AdminCreateUserCommand,
  AdminGetUserCommand
} from "@aws-sdk/client-cognito-identity-provider";
import { randomUUID } from "crypto";
var ORGANIZATIONS_TABLE_NAME = process.env.ORGANIZATIONS_TABLE_NAME || "BillingOrganizations";
var USERS_TABLE_NAME = process.env.USERS_TABLE_NAME || "BillingUsers";
var ACCESS_ROLES_TABLE_NAME = process.env.ACCESS_ROLES_TABLE_NAME || "BillingAccessRoles";
var COGNITO_USER_POOL_ID = process.env.COGNITO_USER_POOL_ID || "";
var FROM_EMAIL = process.env.FROM_EMAIL || "noreply@billing.anahata.ai";
var DEFAULT_ROLES = [
  { name: "Owner", actions: ["*:*"] },
  { name: "Admin", actions: ["*:*"] },
  {
    name: "Manager",
    actions: [
      "users:read",
      "users:write",
      "access-roles:read",
      "invitations:read",
      "invitations:write",
      "organizations:read"
    ]
  },
  {
    name: "Employee",
    actions: [
      "users:read",
      "organizations:read"
    ]
  }
];
var ddb = DynamoDBDocumentClient.from(new DynamoDBClient({}));
var cognito = new CognitoIdentityProviderClient({});
var CORS_HEADERS = {
  "Content-Type": "application/json",
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization"
};
function apiResponse(statusCode, body) {
  return { statusCode, headers: CORS_HEADERS, body: JSON.stringify(body) };
}
function resolveUserId(event) {
  const userId = event.requestContext?.authorizer?.userId;
  if (!userId) throw new Error("userId is required \u2014 must be authenticated");
  return userId;
}
async function ensureCognitoUser(email, tempPassword) {
  try {
    const existing = await cognito.send(
      new AdminGetUserCommand({
        UserPoolId: COGNITO_USER_POOL_ID,
        Username: email
      })
    );
    const sub2 = existing.UserAttributes?.find((a) => a.Name === "sub")?.Value;
    return sub2 || email;
  } catch (err) {
    if (err.name !== "UserNotFoundException") throw err;
  }
  const password = tempPassword || `Temp${randomUUID().slice(0, 8)}!`;
  const createResult = await cognito.send(
    new AdminCreateUserCommand({
      UserPoolId: COGNITO_USER_POOL_ID,
      Username: email,
      UserAttributes: [
        { Name: "email", Value: email },
        { Name: "email_verified", Value: "true" }
      ],
      TemporaryPassword: password,
      MessageAction: "SUPPRESS"
      // Don't send welcome email yet
    })
  );
  const sub = createResult.User?.Attributes?.find((a) => a.Name === "sub")?.Value;
  return sub || email;
}
var handler = async (event) => {
  console.log("EVENT:", JSON.stringify(event));
  try {
    const method = event.httpMethod;
    if (method === "OPTIONS") return apiResponse(200, {});
    if (method === "GET") {
      const userId2 = event.requestContext?.authorizer?.userId;
      if (!userId2) {
        return apiResponse(200, { userId: "anonymous", organizations: [] });
      }
      const { DynamoDBClient: DynamoDBClient2 } = await import("@aws-sdk/client-dynamodb");
      const { DynamoDBDocumentClient: DynamoDBDocumentClient2, QueryCommand: QueryCommand2, BatchGetCommand } = await import("@aws-sdk/lib-dynamodb");
      const ddbList = DynamoDBDocumentClient2.from(new DynamoDBClient2({}));
      const USERS_TABLE = process.env.USERS_TABLE_NAME || "AnahataBillingUsers";
      const ORGS_TABLE = process.env.ORGANIZATIONS_TABLE_NAME || "AnahataBillingOrganizations";
      const memberships = await ddbList.send(new QueryCommand2({
        TableName: USERS_TABLE,
        IndexName: "userId-index",
        KeyConditionExpression: "#uid = :uid",
        ExpressionAttributeNames: { "#uid": "userId" },
        ExpressionAttributeValues: { ":uid": userId2 },
        ProjectionExpression: "orgId"
      }));
      const orgIds = (memberships.Items || []).map((m) => m.orgId).filter(Boolean);
      if (orgIds.length === 0) {
        return apiResponse(200, { userId: userId2, organizations: [] });
      }
      const orgsResult = await ddbList.send(new BatchGetCommand({
        RequestItems: {
          [ORGS_TABLE]: { Keys: orgIds.map((orgId2) => ({ orgId: orgId2 })) }
        }
      }));
      return apiResponse(200, { userId: userId2, organizations: orgsResult.Responses?.[ORGS_TABLE] || [] });
    }
    if (method === "DELETE") {
      return apiResponse(200, { deleted: true });
    }
    if (method !== "POST") {
      return apiResponse(405, { error: "Method not allowed" });
    }
    const userId = resolveUserId(event);
    let body;
    try {
      body = JSON.parse(event.body || "{}");
    } catch {
      return apiResponse(400, { error: "Invalid JSON in request body" });
    }
    if (!body.name || typeof body.name !== "string" || body.name.trim().length === 0) {
      return apiResponse(400, { error: "Organization name is required" });
    }
    const now = (/* @__PURE__ */ new Date()).toISOString();
    const orgId = randomUUID();
    const roleItems = DEFAULT_ROLES.map((role) => ({
      accessRoleId: randomUUID(),
      orgId,
      accessRoleName: role.name,
      actions: role.actions,
      createdBy: userId,
      createdAt: now,
      updatedAt: now
    }));
    const ownerRoleId = roleItems[0].accessRoleId;
    let cognitoSub;
    if (body.userEmail) {
      try {
        cognitoSub = await ensureCognitoUser(body.userEmail);
      } catch (err) {
        console.error("[CREATE_ORG] Cognito error:", err);
        return apiResponse(500, { error: "Failed to create user account" });
      }
    }
    const orgItem = {
      orgId,
      name: body.name.trim(),
      description: body.description || "",
      createdBy: userId,
      createdAt: now,
      updatedAt: now
    };
    if (body.address) orgItem.address = body.address;
    if (body.FEIN) orgItem.FEIN = body.FEIN;
    if (body.orgDomainUrls?.length) orgItem.orgDomainUrls = body.orgDomainUrls;
    if (body.tags?.length) orgItem.tags = body.tags;
    const userItem = {
      userId: cognitoSub || userId,
      orgId,
      userFirstName: (body.userFirstName || "").trim(),
      userLastName: (body.userLastName || "").trim(),
      email: (body.userEmail || "").trim(),
      accessRoles: [ownerRoleId],
      groups: [],
      createdAt: now,
      updatedAt: now
    };
    const transactItems = [
      {
        Put: {
          TableName: ORGANIZATIONS_TABLE_NAME,
          Item: orgItem,
          ConditionExpression: "attribute_not_exists(orgId)"
        }
      },
      ...roleItems.map((roleItem) => ({
        Put: {
          TableName: ACCESS_ROLES_TABLE_NAME,
          Item: roleItem,
          ConditionExpression: "attribute_not_exists(accessRoleId)"
        }
      })),
      {
        Put: {
          TableName: USERS_TABLE_NAME,
          Item: userItem,
          ConditionExpression: "attribute_not_exists(userId) AND attribute_not_exists(orgId)"
        }
      }
    ];
    try {
      await ddb.send(new TransactWriteCommand({ TransactItems: transactItems }));
    } catch (err) {
      if (err.name === "TransactionCanceledException") {
        const reasons = err.CancellationReasons ?? [];
        console.error("[CREATE_ORG] Transaction cancelled:", reasons);
        return apiResponse(409, {
          error: "Organization creation failed \u2014 one or more records already exist",
          details: reasons.filter((r) => r.Code && r.Code !== "None")
        });
      }
      throw err;
    }
    console.log(`[CREATE_ORG] orgId=${orgId} ownerRoleId=${ownerRoleId} userId=${userId}`);
    return apiResponse(201, {
      orgId,
      name: orgItem.name,
      accessRoleId: ownerRoleId,
      userId: userItem.userId,
      roles: roleItems.map((r) => ({ accessRoleId: r.accessRoleId, name: r.accessRoleName }))
    });
  } catch (error) {
    console.error("[CREATE_ORG] Handler error:", error);
    return apiResponse(500, { error: "Internal server error" });
  }
};
export {
  handler
};
//# sourceMappingURL=custom-org-creation.js.map
